<!--
Theme Name: Q for iOS
Description: A clean and simple iOS app news theme featuring: back button, content refresh, custom post types, embeds, infinite list, network detection, off-canvas menu, offline content, pages, posts, responsive, touch, transitions
Version: 1.0
Theme URI: ...
Author: UncatCrea			
Author URI: getwpappkit.com
-->