<!--
Theme Name: Q for Android
Description: A clean and simple Android app news theme featuring: back button, comments, content refresh, custom post types, embeds, infinite list, latest posts, native sharing, network detection, off-canvas menu, offline content, pages, posts, pull to refresh, responsive, status bar, touch, transitions
Version: 1.0
Theme URI: ...
Author: UncatCrea			
Author URI: getwpappkit.com
-->